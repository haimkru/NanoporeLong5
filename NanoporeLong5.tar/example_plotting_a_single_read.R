###imaging_output_example_code####
#author: Haim Krupkin
#date: 03/24/2025

###description###
##this code is an example code as to how to plot a single read from the long5 file###

###pacakges###
library(ggplot2)
library(dplyr)

###analysis###
####load data####
#we are doing a small example code#
long5<-read.csv("combined_merged_signal_fastq_sequences_ready.long5")
unique(long5$sequence_name)
####then we plot####
long5%>%
  dplyr::filter(sequence_name=="d7fc8d36-c976-4b78-b4ff-8031a57b3cc4")%>%
  pivot_longer(cols = c(signal, phred_score), names_to = "measurement", values_to = "value")%>%
  ggplot(aes(x = time, y = value, group = sequence_name)) +
  facet_wrap(  ~paste0(sequence ,"_",sequence_name)+measurement , scales = "free",
               ncol=1) +  # Facet by measurement type
  geom_line(aes(color = sequence_type_plotted), linewidth = 0.2, alpha = 1) +
  geom_text(aes(x = mean_nucleotide_time,
                y = 0,
                label = plotted_nucleotide),show.legend = F,
            size = 3, vjust = -0.5) +  # Add nucleotide labels
  theme_bw() +
  theme(legend.position = "bottom") +
  labs(x = "Time (S)", y = "Value", color = "Portion Of Read")+
  guides(
    color = guide_legend(
      override.aes = list(linewidth = 5)  # Increase the line width in the legend only
    )
  )












