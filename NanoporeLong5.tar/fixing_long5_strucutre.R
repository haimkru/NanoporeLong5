###fixing_long5_strucutre####
#author : haim krupkin
#date : 03/18/2025

###description####

###This script is meant to take in an output file from ###
#/media/data2/hkrupkin/code/nanopore_related/Custom_code/Single_Script_all_DragonRNA_analysis_up_to_plotting/From_fastq_pod5_predict_DragonRNA.sh
#and then the file strucutre is fixed


###packages####
options(repos = c(CRAN = "https://cloud.r-project.org/"))
check_and_install_packages <- function(packages) {
  for (pkg in packages) {
    if (!require(pkg, character.only = TRUE)) {
      install.packages(pkg, dependencies = TRUE)
      library(pkg, character.only = TRUE)
    }
  }
}

# List of required packages
required_packages <- c("tidyr", "dplyr", "stringr", "caret","tidyr")
#print("install tidyverse sepretly cause it can cause problems sometimes")


# Check and install packages
check_and_install_packages(required_packages)

library(tidyr)
library(dplyr)
library(stringr)
library(tidyr)
print("finished loading R packages")
###Analysis###
###defining functiosn####


####loading data####
####long 5 is esentially .csv but of nanopore sequncing run data####
print("we are now reading the file combined_merged_signal_fastq_sequences.csv ")

long5<-read.csv("combined_merged_signal_fastq_sequences.long5")
###1mil is only for testing
#long5<-read.csv("combined_merged_signal_fastq_sequences_top_1_million.csv")



print("finished loading this data")
#### we then need to process a bit the data in a long5 file, for example, fixing the fastq defintions####
print("creating function to process not fully good long5")
process_dataframe <- function(df) {
  # Filter for read information
  read_info <- df %>%
    dplyr::filter(nucleotide == "") %>%
    dplyr::select(time, signal,
     #signal_pa,
     read_name, signal_index, kmer_index_id, sequence)
  
  cat("Read info dimensions:", dim(read_info), "\n")
  print(head(read_info))
  print(str(read_info))
  #print('I just want to take a nappppppppppppppppppppppppppppppppppppppppppppppppp')
  read_info<-read_info%>%
    dplyr::mutate(signal_index=as.numeric(signal_index))%>%
    dplyr::mutate(read_name=as.character(read_name))%>%
    dplyr::mutate(kmer_index_id=as.numeric(kmer_index_id))

  # Filter for FASTQ definitions
  fastq_definitions <- df %>%
    dplyr::filter(!is.na(nucleotide)) %>%
    dplyr::select(sequence_name, nucleotide, nucleotide_index, phred_score, sequence_name_msa_format)
  
  fastq_definitions<-fastq_definitions%>%
    dplyr::mutate(nucleotide_index=as.numeric(nucleotide_index))%>%
    dplyr::mutate(sequence_name=as.character(sequence_name))%>%
    dplyr::mutate(nucleotide=as.character(nucleotide))

  cat("FASTQ definitions dimensions:", dim(fastq_definitions), "\n")
  print(head(fastq_definitions))
  print(str(fastq_definitions))

  # Merge the two dataframes
  read_info_with_fastq_definitions <- fastq_definitions %>%
    merge(read_info,
          by.x = c("sequence_name", "nucleotide_index"),
          by.y = c("read_name", "kmer_index_id"),
          all = TRUE)
  
    cat("Merged dimensions:", dim(read_info_with_fastq_definitions), "\n")


  # Process the merged dataframe
  read_info_with_fastq_definitions <- read_info_with_fastq_definitions %>%
    dplyr::mutate(signal_index = as.numeric(signal_index)) %>%
    dplyr::filter(!is.na(signal_index))
  
  return(read_info_with_fastq_definitions)
}
print("finished creating function to process not fully good long5")

####loading data####
long5$sequence<-"Unknown1"
print("starting function to fix the data")

print("flag0 nucleotide ")
print(table(long5$nucleotide))
long5 <- process_dataframe(long5)
print("done function to fix the data")
print("flag1 nucleotide ")
print(table(long5$nucleotide))

####this is to make sure everyghing is in correct format###
print("making the data as slim as possible")
long5<-long5%>%
  dplyr::group_by(sequence_name) %>%
  dplyr::mutate(signal_index=as.numeric(signal_index))%>%
  dplyr::select(sequence_name,nucleotide_index ,nucleotide ,phred_score ,time,signal,signal_index ,sequence)
print("finished making the data as slim as possible")
print("flag1 nucleotide ")
print(table(long5$nucleotide))
####we are gonna run a function to classifiy what is unknown definetly,
#and what might be unknown###
#first we create a dataframe setting sequence type for all the reads as Unknown##
#then we are gonna detect the PolyA,
#and define everything after the polyA as Unknown_important###
#maybe stuff in the signal before the polyA are important, but
#we dont care as much about them, truth be told
#
print("adding column defintion of sequence as unknown")
long5<-long5%>%
  dplyr::mutate(sequence_type="Unknown")
#long5_backup_pre_polyA<-long5
#long5<-long5_backup_pre_polyA
###
print("flag1 nucleotide ")
print(table(long5$nucleotide))
print("flag1 table long5" )
print(table(long5$sequence_type) )
print("creating function to trim PolyA and get defintions of regions of PolyA")


trim_sequences <- function(df) {
  # Initialize a vector to hold trimmed sequences
  #trimmed_sequences <- character(nrow(df))
  #df<-long5%>%
  #  dplyr::filter(sequence_name =="ff874adc-98a8-4796-a29f-d80c4fad2f38")%>%
  #  mutate(sequence_type="Unknown")%>%
  #  dplyr::select(sequence_name,nucleotide_index,nucleotide,sequence_type)%>%
  #  distinct()
  df$nucleotide<-df$nucleotide
  #print("flag 2 nucleotide")
  #print(table(df$nucleotide))

  df$nucleotide<-as.character(df$nucleotide)
  #print("flag 3 nucleotide")
  #print(table(df$nucleotide))
  # Iterate through each row of the data frame
  running_sequence=paste(df$nucleotide,collapse="")
  #print("First running seuqnce: ")
  #print(running_sequence)
  #print("into loop")
  #print(nchar(running_sequence))
  pretrimming_length=nchar(running_sequence)
  if (nchar(running_sequence) >= 16 && grepl("AAAA", substr(running_sequence, 1, 15))) {
    #print("Detected PolyA Found")
    while ((nchar(running_sequence) >= 16 && grepl("AAAA", substr(running_sequence, 1, 15))) || substring(running_sequence, 1, 1) == "A") {
      running_sequence=substr(running_sequence, 2, nchar(running_sequence))
      #print(running_sequence)
    }
  }else {
    #print("No PolyA")
    do_noting=T
  }
  #print(running_sequence)
  #print("length_trimmed")
  aftertrimming_length=nchar(running_sequence)
 # print(aftertrimming_length)
  df%>%
    mutate(after_correction=ifelse(aftertrimming_length<=nucleotide_index,"PolyA",sequence_type))%>%
    dplyr::select(-nucleotide,sequence_type )
  
  
}
print("flag1 nucleotide ")
print(table(long5$nucleotide))
print("flag2 table long5" )
print(table(long5$sequence_type) )
print("Actully doing PolyA")
head(long5)
long5_polyA <- long5 %>%
  select(sequence_name, nucleotide_index, nucleotide, sequence_type) %>%
  distinct() %>%
  group_by(sequence_name) %>%  # Group by the desired column
  do(trim_sequences(.))%>%
  group_by(sequence_name) %>%  # Group by the desired column
  dplyr::mutate(nucleotide_index=as.numeric(nucleotide_index))%>%
  dplyr::mutate(nucleotide_index = max(nucleotide_index) - nucleotide_index)
print("finished doing PolyA detection")
print("flag1 nucleotide ")
print(table(long5_polyA$nucleotide))
print("merging with PolyA detection")
print("flag3 table long5" )
print(table(long5_polyA$after_correction))
print(table(long5$sequence_type) )
long5<-long5%>%
  mutate(plotted_nucleotide=nucleotide)%>%
  mutate(og_sequence_type=sequence_type)%>%
  merge(long5_polyA,
        by.x=c("sequence_name","nucleotide_index"),
        by.y=c("sequence_name","nucleotide_index"),all.x=T)%>%
  dplyr::ungroup()%>%
  dplyr::group_by(sequence_name) %>%
  dplyr::mutate(time=as.numeric(time))%>%
  dplyr::mutate(time_fliped = max(time) - time) %>%
  dplyr::ungroup()%>%
  dplyr::group_by(nucleotide_index,sequence_name)%>%
  dplyr::mutate(mean_nucleotide_time=mean(time))%>%
  mutate(sequence_type_plotted=ifelse(after_correction=="PolyA",after_correction,og_sequence_type))%>%
  dplyr::mutate(sequence_type_plotted=ifelse(sequence_type_plotted=="Unknown","RNA",sequence_type_plotted))%>%
  dplyr::mutate(sequence_type_plotted=ifelse(is.na(nucleotide),"Unknown",sequence_type_plotted))
print("flag4 table long5" )
print(table(long5$sequence_type_plotted) )
long5$signal<-as.numeric(long5$signal)
print("done erging with PolyA detection")
print("Adding Dwell time")

long5<-long5%>%
  dplyr::ungroup()%>%
  dplyr::group_by(sequence_name,nucleotide_index )%>%
  dplyr::mutate(number_of_measurments=dplyr::n())%>%
  dplyr::mutate(dwell_time=number_of_measurments*(1/4000))
print("saving all the data now :) ")

print("flag5 table long5" )
print(table(long5$sequence_type_plotted) )


#Format of the file:
#""=row number (not important)
#"sequence_name"= read name
#"nucleotide_index"= what is the nucleotide index in the fastq if it is fliped, ie if it is read 5' to 3'
#"nucleotide"= what is the nucleotide in the fastq for this region of the signal (not important)
#"phred_score"= what is the phred score from the fastq for this nucleotide
#"time"= in seconds, which time point along the read was this signal measured
#"signal"= Current in nanopore in pA
#"signal_index"= index of the signal
#"sequence"= classification (not important)
#"sequence_type.x" = not important, intermediate for fastq defintions
#"plotted_nucleotide"= what  fastq nucleotide should be there
#"og_sequence_type" = not important
#"sequence_type.y" = not important
#"after_correction" = needed to add the polyA definitions
#"time_fliped"= needed to do the polyA defintions correctly
#"mean_nucleotide_time" = not impotrant
#"sequence_type_plotted" = region definition
#"number_of_measurments" = number of times nueclodite was measured (not important)
#"dwell_time" = dwell time
long5<-long5%>%
  dplyr::select(sequence_name,nucleotide_index,
  phred_score,dwell_time,
  time,signal,signal_index,
  plotted_nucleotide,
  sequence_type_plotted)


write.csv(long5,"combined_merged_signal_fastq_sequences_ready.long5")


