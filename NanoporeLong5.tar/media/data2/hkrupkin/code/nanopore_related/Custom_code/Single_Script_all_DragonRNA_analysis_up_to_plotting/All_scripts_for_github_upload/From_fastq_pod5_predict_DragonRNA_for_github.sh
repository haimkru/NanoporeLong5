#!/bin/bash

start_time=$(date +%s)  # Get the start time in seconds


# Check if the correct number of arguments is provided
if [ "$#" -ne 5 ]; then
    echo "Usage: $0 <input.fastq> <input.pod5> <output_directory> <N_threads> <directory_of_scripts>"
    exit 1
fi

# Assign arguments to variables
FASTQ_FILE="$1"
POD5_FILE="$2"
OUTPUT_DIR="$3"
N_threads="$4"
scripts_dir="$5"
# Check if the FASTQ file exists
if [ ! -f "$FASTQ_FILE" ]; then
    echo "Error: FASTQ file '$FASTQ_FILE' not found!"
    exit 1
fi

# Check if the .pod5 file exists
if [ ! -f "$POD5_FILE" ]; then
    echo "Error: .pod5 file '$POD5_FILE' not found!"
    exit 1
fi

# Check if the output directory exists, create it if it does not
if [ ! -d "$OUTPUT_DIR" ]; then
    echo "Output directory '$OUTPUT_DIR' does not exist. Creating it..."
    mkdir -p "$OUTPUT_DIR"
fi
#if [ ! -d "$N_threads" ]; then
#    echo "N_threads  '$N_threads' not found, please. define it"
#fi
# Print the names of the files and the output directory
echo "Processing files:"
echo "FASTQ file: $FASTQ_FILE"
echo ".pod5 file: $POD5_FILE"
echo "Output directory: $OUTPUT_DIR"
echo "Number of threads: $N_threads"
echo "Directory of scripts: $scripts_dir"
cd $OUTPUT_DIR
# Add your processing logic here
# Example: output files can be created in the output directory
# OUTPUT_FASTQ="$OUTPUT_DIR/output.fastq"
# OUTPUT_POD5="$OUTPUT_DIR/output.pod5"
#######################################
###creating paf files####
###we are gonna make the .bam file for the later .paf file
#we also need the .blow5 file

echo "activating conda enviorment"
source activate python3.7_for_github
echo "activated conda enviorment"
cd "$OUTPUT_DIR"
echo "Current working directory: $(pwd)"
echo "filtering pod5 file as well"
echo "first we create a file with all the read ids"
cat "$FASTQ_FILE" | awk '(NR-1)%4==0 {print substr($0,2)}' | awk '{print $1}' > read_ids.txt
pod5 filter "$POD5_FILE" --output filtered.pod5 --ids read_ids.txt --missing-ok 


source activate basic_env_python3.8_github
blue-crab p2s filtered.pod5 -o signal_data.blow5
echo "blue crab finished"
source deactivate 
source activate python3.7_for_github
echo "activated python3.7_for_github"
echo "start slow dorado"
"$scripts_dir"/slow5-dorado/bin/slow5-dorado basecaller "$scripts_dir"/rna004_130bps_sup@v3.0.1 signal_data.blow5  --emit-moves > basecalls.sam
echo "done slow dorado"
echo "start squigualiser"
"$scripts_dir"/squigualiser/squigualiser reform --sig_move_offset 0 --kmer_length 1 -c --bam basecalls.sam --rna  -o try3.paf
echo "done squigualiser"

#######################################
#Creating Fasta file from fastq to enable polyA trimming later
base_name=$(basename "$FASTQ_FILE" .txt)
base_name="${base_name%.*}"

# Define the output FASTA file name
fasta_file="${base_name}_converted_to_fasta.fasta"
# Process the .txt file and convert it to FASTA format
echo "creating fasta"
echo "$fasta_file"
echo "text file is : "
echo "$txt_file"
cat "$FASTQ_FILE" | awk '(NR-1)%4==0 {print ">" substr($0,2)} (NR-1)%4==1 {print}' > "$fasta_file"
echo "done creating fasta"

###we are gonna flip the fastq as well.
# Define the output FASTA file name
base_name="${base_name%.*}"
flipped_fastq="${base_name}_flipped.txt"
# Process the .txt file and convert it to FASTA format
echo "flipping"
python "$scripts_dir"/flipping_fastq_files.py "$FASTQ_FILE" "$flipped_fastq"
echo "flipped"
###creating paf file from fastq####

###we are gonna make the paf file beforehand

#python /media/data2/hkrupkin/code/nanopore_related/Custom_code/Single_Script_all_DragonRNA_analysis_up_to_plotting/From_Fastq_and_pod5_and_fasta_to_paf.py --fastq "$flipped_fastq" --pod5 "$POD5_FILE" --paf try3.paf --output "$OUTPUT_DIR"
python "$scripts_dir"/split_batch_fastq.py --fastq "$flipped_fastq" --pod5 filtered.pod5 --paf try3.paf --output "$OUTPUT_DIR" --reads_per_batch 100 --num_threads "$N_threads" --scripts_dir "$scripts_dir"

###we re then gonna apply a little R script to fix the strucutre of the code###
Rscript "$scripts_dir"/fixing_long5_strucutre.R

###then as a finishing touch, we are gonna run a little algorithm to store the preidction scores

echo "done doing everything"
# Exit successfully
exit 0



end_time=$(date +%s)  # Get the end time in seconds
elapsed_time=$(( end_time - start_time ))  # Calculate elapsed time

echo "Script execution time: $elapsed_time seconds"