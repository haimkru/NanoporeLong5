#****Installation stuff:****
conda env create -f basic_env_python3.8_github.yml
conda install -c r r

conda env create -f python3.7_for_github.yml
source activate python3.7_for_github
conda install -c r r

#**First We Install blue-crab**
pip install blue-crab
#**Then we Install slow5 dorado**

wget https://github.com/hiruna72/slow5-dorado/releases/download/v0.8.3/slow5-dorado-v0.8.3-x86_64-linux.tar.xz -O slow5-dorado.tar.xz

tar xf slow5-dorado.tar.xz
#**we also need to install the correct slow5 dorado model, currently its set to the RNA model for RNA004**

#But this code can be changed, to another model,
#just download the other model, and in the file From_fastq_pod5_predict_DragonRNA_for_github.sh
#change the row 63 the model used to the correct model
slow5-dorado/bin/slow5-dorado download --model rna004_130bps_sup@v3.0.1

#**Then we Install squigualiser**
wget https://github.com/hiruna72/squigualiser/releases/download/v0.6.3/squigualiser-v0.6.3-linux-x86-64-binaries.tar.gz -O squigualiser.tar.gz
tar xf squigualiser.tar.gz
#cd squigualiser

#**we also need to install R to be able to do the analyses and to reformat the long5 file**

conda install -c r r

