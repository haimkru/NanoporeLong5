import os
import sys
import argparse
import concurrent.futures
import time

def split_fastq(fastq_file, reads_per_batch):
    """Split the FASTQ file into multiple files with a specified number of reads."""
    batch_number = 0
    output_files = []
    
    with open(fastq_file, 'r') as infile:
        while True:
            # Read the specified number of reads (4 lines per read in FASTQ)
            lines = []
            for _ in range(reads_per_batch):  # Read exactly reads_per_batch reads
                # Read 4 lines for each read
                read_lines = [infile.readline() for _ in range(4)]
                if not read_lines[0]:  # Check if the first line is empty (EOF)
                    break
                lines.extend(read_lines)  # Add the read lines to the batch
            
            if not lines:
                break  # End of file
            
            # Create a new batch file
            batch_file_name = f'batch{batch_number}.fastq'
            output_files.append(batch_file_name)
            print("Saving FASTQ batch to:", batch_file_name)
            with open(batch_file_name, 'w') as outfile:
                outfile.writelines(lines)
            
            batch_number += 1  # Increment the batch number for the next file
    
    return output_files

def process_batch(batch_file, pod5_file, paf_file, output_dir, batch_number,scripts_dir):
    """Process a single batch file with the specified script."""
    # Create a directory for the current batch
    batch_dir = os.path.join(output_dir, f'batch{batch_number}')
    os.makedirs(batch_dir, exist_ok=True)
    
    # Move the batch file to the new directory
    batch_file_path = os.path.join(batch_dir, os.path.basename(batch_file))
    os.rename(batch_file, batch_file_path)
    
    current_directory = os.getcwd()  # Get the current working directory
    print("Current directory is:", current_directory)
    
    pod5_file_path = os.path.join(current_directory, pod5_file)
    paf_file_path = os.path.join(current_directory, paf_file)
    
    command = f"python {scripts_dir}/From_Fastq_and_pod5_and_fasta_to_paf.py --fastq {batch_file_path} --pod5 {pod5_file_path} --paf {paf_file_path} --output {batch_dir}"
    
    print("We are going to run the command:")
    print(command)
    
    # Execute the command
    os.system(command)

def process_batches(output_files, pod5_file, paf_file, output_dir, num_threads,scripts_dir):
    """Process each batch file with multiprocessing."""
    with concurrent.futures.ProcessPoolExecutor(max_workers=num_threads) as executor:
        futures = []
        #for batch_number, batch_file in enumerate(output_files[0:20]): #this will make the code run on only the first 20 batches of reads, this is good since it can increase speed.
        #which is especially important for code development
        #Please do delete/make the following line a note if this setting is turned on :) Thanks!
        #for batch_number, batch_file in enumerate(output_files[0:8]):
        for batch_number, batch_file in enumerate(output_files):
            futures.append(executor.submit(process_batch, batch_file, pod5_file, paf_file, output_dir, batch_number,scripts_dir))
            # Print a message between each command
            print(f"Submitted batch {batch_number} for processing.")
        
        # Wait for all futures to complete
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()  # This will raise an exception if the batch processing failed
            except Exception as e:
                print(f"Batch processing generated an exception: {e}")

def combine_csv_files(output_dir):
    """Combine all merged_signal_fastq_sequences.csv files into one using cat."""
    combined_file_path = os.path.join(output_dir, 'combined_merged_signal_fastq_sequences.long5')
    
    # Create or clear the combined file
    with open(combined_file_path, 'w') as combined_file:
        combined_file.write("")  # Clear the file if it exists

    # Iterate through each batch directory and concatenate CSV files
    for batch_number in range(len(os.listdir(output_dir))):
        batch_dir = os.path.join(output_dir, f'batch{batch_number}')
        csv_file_path = os.path.join(batch_dir, 'merged_signal_fastq_sequences.csv')
        
        if os.path.exists(csv_file_path):
            print(f"Appending {csv_file_path} to {combined_file_path}")
            # Use the cat command to append the contents of the CSV file
            os.system(f"cat {csv_file_path} >> {combined_file_path}")

    print(f"Combined CSV file created at: {combined_file_path}")


def main():
    start_time = time.time()
    parser = argparse.ArgumentParser(description='Split FASTQ file and process batches.')
    parser.add_argument('--fastq', required=True, help='Input FASTQ file')
    parser.add_argument('--pod5', required=True, help='POD5 file')
    parser.add_argument('--paf', required=True, help='Output PAF file')
    parser.add_argument('--output', required=True, help='Output directory')
    parser.add_argument('--reads_per_batch', type=int, default=100, help='Number of reads per batch')
    parser.add_argument('--num_threads', type=int, default=4, help='Number of threads to use for processing')
    parser.add_argument('--scripts_dir',required=True, help='Directory in which we have the scripts for NanoporeLong5')

    args = parser.parse_args()
    
    # Ensure output directory exists
    os.makedirs(args.output, exist_ok=True)
    
    # Split the FASTQ file
    output_files = split_fastq(args.fastq, args.reads_per_batch)
    
    # Process each batch
    process_batches(output_files, args.pod5, args.paf, args.output, args.num_threads, args.scripts_dir)
    combine_csv_files(args.output)

    end_time = time.time()
    
    # Calculate and print the elapsed time
    elapsed_time = end_time - start_time
    print(f"Total execution time for entire crawl5 creation is : {elapsed_time:.2f} seconds")


if __name__ == '__main__':
    main()