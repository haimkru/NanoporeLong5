#author: Haim krupkin
#date: 03/13/2025
#descirption
#this code is intended to complete all hte steps to create the dataframes required to
#do the signal to nucldoite analysis for DragonRNAs
#but it can be run on any sequences


import os
import shutil
import subprocess
import glob
import pod5
import pod5 as p5
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import pandas as pd
import Bio
from Bio import SeqIO
import time
import seaborn as sns
from Bio import AlignIO
from concurrent.futures import ProcessPoolExecutor
import time
import argparse

def extract_read_names(fastq_file):
    """Extract read names from a FASTQ file."""
    read_names = set()
    with open(fastq_file, 'r') as f:
        for line in f:
            if line.startswith('@'):  # FASTQ read names start with '@'
                read_name = line[1:].strip().split(' ')[0]  # Get the read name
                read_names.add(read_name)
    return read_names
def extract_all_reads_info(path_pod5,read_names_selected):
    all_reads_info = []
    if read_names_selected is None:
        print("entering into state with no selection of reads")
        with p5.Reader(path_pod5) as reader:
            print("this is for printing without selection of reads")
            for read in reader.reads():
                read_info = {}
                
                # Store relevant attributes in the dictionary
                read_info['ID'] = str(read.read_id)
                read_info['Run Info'] = read.run_info
                read_info['Sample Rate'] = read.run_info.sample_rate
                read_info['Signal Shape'] = read.signal.shape
                read_info['Signal listed'] = read.signal.tolist()  # Convert to list for easier storage
                read_info['Signal raw'] = read.signal  # Convert to list for easier storage
                read_info['Signal pA'] = read.signal_pa 

                all_reads_info.append(read_info)

        return all_reads_info
    else:
        print("Entering into pod5 with selection of reads")
        with p5.Reader(path_pod5) as reader:
                with open("reads_not_related_to_our_selected_pod5.txt", "w") as not_related_file:
    # Assuming 'some_other_source' is a list of reads you are checking against
                    for read in reader.reads():
                        #print(read_names_selected)
                        #time.sleep(2)
                        if str(read.read_id) in list(read_names_selected):
                            #print("found a matchin read")
                            read_info = {}
                            # Store relevant attributes in the dictionary
                            read_info['ID'] = str(read.read_id)
                            read_info['Run Info'] = read.run_info
                            read_info['Sample Rate'] = read.run_info.sample_rate
                            read_info['Signal Shape'] = read.signal.shape
                            read_info['Signal listed'] = read.signal.tolist()  # Convert to list for easier storage
                            read_info['Signal raw'] = read.signal  # Convert to list for easier storage
                            read_info['Signal pA'] = read.signal_pa 
                            all_reads_info.append(read_info)
                        else:
                            # Write the read ID to the file if not found
                            not_related_file.write(f"{read.read_id}\n")
        return all_reads_info
    
def fastq_to_dataframe(fastq_file):
    # Initialize an empty list to store the data
    data = []
    # Read the FASTQ file
    for record in SeqIO.parse(fastq_file, "fastq"):
        sequence_name = record.id
        sequence = str(record.seq)
        phred_scores = record.letter_annotations["phred_quality"]

        # Iterate through each nucleotide in the sequence
        running_index_without_gaps = 0
        for index, nucleotide in enumerate(sequence):
            # Check if the nucleotide is a valid base
            # Append a dictionary for each nucleotide
            sequence_name_msa_format = sequence_name.rsplit('-', 1)[0]
            data.append({
                'sequence_name': sequence_name,
                'nucleotide': nucleotide,
                'nucleotide_index': index,
                'phred_score': phred_scores[index],
                'sequence_name_msa_format':str(sequence_name[0:30])
            })

    # Create a DataFrame from the list of dictionaries
    df = pd.DataFrame(data)
    return df

def process_row(row, time_and_signal_all_pd,output_directory):
    start_rwa = row['start_raw'] + 1
    kmer_sizes = row['kmer_sizes']
    #print("kmer_sizes")
    #print(kmer_sizes)
    numbers_str = kmer_sizes.split(':')[-1].strip(',')
    kmer_indexes_list = [int(num) for num in numbers_str.split(',') if num]
    #print("kmer_indexes_list")
    #print(kmer_indexes_list)
    read_name_we_are_going_to_work_on = row['read_id']
    #print("read_name_we_are_going_to_work_on")
    #print(read_name_we_are_going_to_work_on)
    current_df = time_and_signal_all_pd[time_and_signal_all_pd['read_name'] == read_name_we_are_going_to_work_on].copy()
    #print("current_df")
    #print(current_df)
    current_index = start_rwa
    #print("current_index")
    #print(current_index)
    # Create an array of kmer_index_id values based on the cumulative sum of kmer_indexes_list
    kmer_index_ids = np.repeat(np.arange(1, len(kmer_indexes_list) + 1), kmer_indexes_list)
    #print("kmer_index_ids")
    #print(kmer_index_ids)
    # Create an array of signal_index ranges
    starting_indices = np.concatenate([[current_index + sum(kmer_indexes_list[:i])] for i in range(len(kmer_indexes_list) + 1)])
    #print("starting_indices")
    #print(starting_indices)
    # Create the ranges for each k-mer size
    ranges = [np.arange(start, start + size) for start, size in zip(starting_indices[:-1], kmer_indexes_list)]
    #print("ranges")
    #print(ranges)
    #    Concatenate all the generated indices into a single array
    signal_indices = np.concatenate(ranges)
    #print("signal_indices")
    #print(signal_indices)
    # Assign kmer_index_id to the DataFrame based on the signal_index
    mask = current_df['signal_index'].isin(signal_indices)
    #print("mask")
    #print(mask)
    current_df.loc[mask, 'kmer_index_id'] = kmer_index_ids[:mask.sum()]
    #print("")
    # Calculate max kmer index and max signal index for the biggest kmer in read
    #print("printing kmer index id: ")
    #print(current_df['kmer_index_id'])
    #print("done printing kmer index id :3")
    kmer_index_numeric = pd.to_numeric(current_df.loc[:, 'kmer_index_id'], errors='coerce')
    #print("kmer_index_numeric")
    #print(kmer_index_numeric)
    max_kmer_index = kmer_index_numeric.max()
    #print("max_kmer_index")
    #print(max_kmer_index)
    max_signal_index_for_biggest_kmer_in_read = current_df.loc[current_df['kmer_index_id'] == max_kmer_index, 'signal_index'].max()
    #print("max_signal_index_for_biggest_kmer_in_read")
    #print(max_signal_index_for_biggest_kmer_in_read)
    # Update kmer_index_id for 'Start_noise' and 'end noise'
    current_df.loc[current_df['kmer_index_id'] == 'Start_noise', 'kmer_index_id'] = 'Start_noise'
    current_df.loc[current_df['signal_index'] > max_signal_index_for_biggest_kmer_in_read, 'kmer_index_id'] = 'end noise'
    
    output_file_name = f"{read_name_we_are_going_to_work_on}_one_read.csv"
    output_file_path = os.path.join(output_directory, output_file_name)
    
    # Create the output directory if it doesn't exist

    # Save the DataFrame to a CSV file
    current_df.to_csv(output_file_path, index=False)
    return None


def main(fastq_file_path, pod5_file_path, paf_file_path, output_directory_base):
    """
    Main function to process the given files.

    Parameters:
    fastq_file_path (str): Path to the FASTQ file.
    pod5_file_path (str): Path to the POD5 file.
    paf_file_path (str): Path to the PAF file.
    output_base_dir (str): Base directory for output files.
    
    Returns:
    None
    """
    # Placeholder for processing logic
    print("Processing files...")
    print(f"FASTQ file: {fastq_file_path}")
    print(f"POD5 file: {pod5_file_path}")
    print(f"PAF file: {paf_file_path}")
    print(f"Output base directory: {output_directory_base}")
    # Change the current working directory to output_directory_base
    os.chdir(output_directory_base)

# Verify the current working directory
    current_directory = os.getcwd()
    print(f"Current working directory: {current_directory}") 
    reads = {}
    read_names_selected=[]
    for record in SeqIO.parse(fastq_file_path, "fastq"):
        read_name = record.id
        read_names_selected.append(read_name)
        phred_scores = np.array(record.letter_annotations["phred_quality"])
        sequence = str(record.seq)  # Store the sequence as a string
        #print("The Phred scores from the FASTQ are the following: ", phred_scores)
        reads[read_name] = (sequence, phred_scores)  # Store both sequence and Phred scores as a tuple

    ###loading the MSA data as well####



    # Example usage
    #print("finsihed loading reads from fastq")
    #print("the reads names are : ")
    #print(read_names_selected)

    #print("loading pod5 data")
    all_reads_info = extract_all_reads_info(pod5_file_path,read_names_selected)    
    time_and_signal_all = []
    runing_index=0
    #print("converting read's signal into signal dataframe")
    for read_info in all_reads_info:
        #print("This is read number: ")
        #print(runing_index)
        #print(read_info['ID'])
        #print(read_info.keys())
        sample_rate = read_info['Sample Rate']
        signal_pa=read_info['Signal pA']
        #print(signal_pa)
        #print(sample_rate)
        # Compute the time steps over the sampling period
        time = np.arange(len(signal_pa)) / sample_rate
        signal_index=-1
        runing_index+=1
        for t, signal in zip(time, signal_pa):
            time_and_signal_all.append({'time': t,
                                        'signal': signal,
                                        #"signal_pa":signal_pa,
                                        'read_name': read_info['ID'],
                                        "signal_index":signal_index})
            signal_index+=1
    time_and_signal_all_pd = pd.DataFrame(time_and_signal_all)
    #print(time_and_signal_all_pd)
    time_and_signal_all_pd['signal_index'] = time_and_signal_all_pd.groupby('read_name').cumcount()+1
    #print(time_and_signal_all_pd)
    ###reading hte paf file#
    file_name = 'time_and_signal_all_pd_af_hk_3.csv'
    # Check if the file exists
    if os.path.exists(file_name):
        # Read the CSV file into a DataFrame
        time_and_signal_all_pd = pd.read_csv(file_name)
        #print("File exists. DataFrame has been loaded.")
    else:
        print("File does not exist.")
        paf_data = pd.read_csv(paf_file_path, sep='\t')
        #print(paf_data)
        new_column_names = [
            'read_id', #1
            'len_raw_signal', #2
            'start_raw', #3
            'end_raw', #4
            'strand', #5
            'read_id2',
            'len_kmer', #6
            'start_kmer', #7
            'end_kmer', #8
            'matches', #9
            'len_block', #10
            'mapq', #11
            'kmer_sizes' #12
        ]
        paf_data.columns = new_column_names
        #print("paf data with new column names: ")
        #print(paf_data)

        ##
        filtered_paf_data = paf_data[paf_data['read_id'].isin(time_and_signal_all_pd['read_name'].unique())]
        #print("filtered paf data: ")
        #print(filtered_paf_data)
        ###
        row_index_running=0
        time_and_signal_all_pd['kmer_index_id'] = 'Start_noise'
        output_directory = os.path.join(output_directory_base, "sub_read_results")
        os.makedirs(output_directory, exist_ok=True)

        
        # Use ProcessPoolExecutor to parallelize the processing of rows
        max_workers = 1  # Change this number to control the number of concurrent jobs

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for _, row in filtered_paf_data.iterrows():
                futures.append(executor.submit(process_row, row, time_and_signal_all_pd, output_directory))
            for future in futures:
                future.result()  # Wait for all futures to complete # Wait for all futures to complete




        combined_file_path = os.path.join(output_directory, "combined_results.csv")

        # Use subprocess to concatenate all CSV files into a single file
        csv_files = glob.glob(os.path.join(output_directory, "*.csv"))
        if csv_files:
            # Create the command to concatenate the CSV files
            command = ["cat"] + csv_files

            # Open the combined file in write mode
            with open(combined_file_path, 'w') as combined_file:
                # Run the command and redirect output to the combined file
                subprocess.run(command, stdout=combined_file)
        else:
            print("No CSV files found in the specified directory.")

        # Read the combined CSV file into a DataFrame
        time_and_signal_all_pd = pd.read_csv(combined_file_path)
        time_and_signal_all_pd.to_csv('time_and_signal_all_pd_af_hk_3.csv', index=False)
    # Example usage
    df_fastqs = fastq_to_dataframe(fastq_file_path)
    #print(df_fastqs)
    df_fastqs.to_csv('fastq_to_dataframe.csv', index=False)



    #print(df_fastqs)
    df_fastqs.to_csv('df_fastqs_to_df.csv', index=False)
    file_msa_with_signal_path="merged_signal_fastq_sequences.csv"
    if os.path.exists(file_msa_with_signal_path):
        # Read the CSV file into a DataFrame
        merged_signal_msa_fastq_sequences = pd.read_csv(file_msa_with_signal_path)
        #print("File exists. DataFrame has been loaded.")
    else:
        #print("File does not exist.")
        df_fastqs['nucleotide_index'] = pd.to_numeric(df_fastqs['nucleotide_index'], errors='coerce')
        df_fastqs['nucleotide_index'] = df_fastqs['nucleotide_index']+1
        df_fastqs['nucleotide_index'] = df_fastqs['nucleotide_index'].astype(str)
        time_and_signal_all_pd['kmer_index_id'] = pd.to_numeric(time_and_signal_all_pd['kmer_index_id'], errors='coerce').fillna(-1)
        #time_and_signal_all_pd['kmer_index_id'] = time_and_signal_all_pd['kmer_index_id']+1
        #time_and_signal_all_pd['kmer_index_id'] = time_and_signal_all_pd['kmer_index_id'].replace(0, np.nan)

        
        time_and_signal_all_pd['kmer_index_id'] = time_and_signal_all_pd['kmer_index_id'].astype(str)  # or int if you prefer integers

        merged_signal_msa_fastq_sequences = pd.merge(
            df_fastqs,
            time_and_signal_all_pd,
            left_on=["sequence_name", "nucleotide_index"],
            right_on=["read_name", "kmer_index_id"],
            how='outer'  # This keeps all rows from both DataFrames
        )
        merged_signal_msa_fastq_sequences.to_csv(file_msa_with_signal_path, index=False)
    #print(merged_signal_msa_fastq_sequences)



if __name__ == "__main__":
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Process some FASTQ and POD5 files.')
    
    parser.add_argument('--fastq', required=True, help='Path to the FASTQ file')
    parser.add_argument('--pod5', required=True, help='Path to the POD5 file')
    parser.add_argument('--paf', required=True, help='Path to the PAF file')
    parser.add_argument('--output', required=True, help='Base output directory')

    # Parse the command line arguments
    args = parser.parse_args()

    # Print the received arguments
    print(f"FASTQ file path: {args.fastq}")
    print(f"POD5 file path: {args.pod5}")
    print(f"PAF file path: {args.paf}")
    print(f"Output directory base: {args.output}")

    # Create the output directory if it doesn't exist
    os.makedirs(args.output, exist_ok=True)

    start_time = time.time()

    # Call the main function with the provided arguments
    main(args.fastq, args.pod5, args.paf, args.output)

    end_time = time.time()

    # Calculate the elapsed time
    elapsed_time = end_time - start_time
    print(f"Elapsed time for main function: {elapsed_time:.2f} seconds")


