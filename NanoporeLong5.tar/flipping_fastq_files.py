import sys

def flip_sequences(input_file, output_file):
    with open(input_file, 'r') as infile:
        # Read all lines from the input FASTQ file
        lines = infile.readlines()

    # Check if the number of lines is a multiple of 4 (standard FASTQ format)
    if len(lines) % 4 != 0:
        raise ValueError("Input file does not appear to be a valid FASTQ file.")

    # Create a list to hold the flipped sequences
    flipped_sequences = []

    # Process each sequence in the FASTQ file
    for i in range(0, len(lines), 4):
        # Flip the sequence and the quality score
        header = lines[i]  # Header line
        sequence = lines[i + 1].strip()[::-1]  # Sequence line (reversed)
        plus = lines[i + 2]  # Plus line
        quality = lines[i + 3].strip()[::-1]  # Quality score line (reversed)

        # Append the flipped sequence to the list
        flipped_sequences.append(header)
        flipped_sequences.append(sequence + '\n')  # Add newline
        flipped_sequences.append(plus)
        flipped_sequences.append(quality + '\n')  # Add newline

    # Write the flipped sequences to the output FASTQ file
    with open(output_file, 'w') as outfile:
        outfile.writelines(flipped_sequences)

    print(f"Flipped sequences written to: {output_file}")

# Main function to handle command-line arguments
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python flip_fastq.py <input_fastq> <output_fastq>")
        sys.exit(1)

    input_fastq = sys.argv[1]  # First command-line argument
    output_fastq = sys.argv[2]  # Second command-line argument

    try:
        flip_sequences(input_fastq, output_fastq)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)